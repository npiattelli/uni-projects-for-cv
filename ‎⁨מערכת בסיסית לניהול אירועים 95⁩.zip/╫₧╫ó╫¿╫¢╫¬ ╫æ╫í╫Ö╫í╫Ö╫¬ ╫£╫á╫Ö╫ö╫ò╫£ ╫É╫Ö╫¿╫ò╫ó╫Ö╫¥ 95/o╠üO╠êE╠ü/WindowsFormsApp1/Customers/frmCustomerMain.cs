﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmCustomerMain : Form
    {
        public frmCustomerMain()
        {
            InitializeComponent();
        }

        private void SearchCustomer_Click(object sender, EventArgs e)
        {
            SearchingCustomer SearchForm = new SearchingCustomer();
            SearchForm.ShowDialog(this);
        }

        private void createNewCustomer_Click(object sender, EventArgs e)
        {
            CreatingCustomer form2 = new CreatingCustomer();
            form2.ShowDialog(this);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmCustomerMain_Load(object sender, EventArgs e)
        {

        }
    }
}
