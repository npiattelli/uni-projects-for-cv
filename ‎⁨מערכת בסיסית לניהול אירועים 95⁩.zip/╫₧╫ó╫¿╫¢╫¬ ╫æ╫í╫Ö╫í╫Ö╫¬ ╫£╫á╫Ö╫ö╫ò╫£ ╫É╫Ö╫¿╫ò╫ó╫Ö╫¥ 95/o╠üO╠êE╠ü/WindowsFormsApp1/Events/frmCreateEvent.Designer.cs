﻿namespace GROUP30
{
    partial class frmCreateEvent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbEventStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbEventType = new System.Windows.Forms.ComboBox();
            this.back = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblBudget = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.txtBudget = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.lblCaption = new System.Windows.Forms.Label();
            this.txtEventId = new System.Windows.Forms.TextBox();
            this.dtpEventDate = new System.Windows.Forms.DateTimePicker();
            this.cmbEventTime = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.newEvent = new System.Windows.Forms.Label();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.btnEmergency = new System.Windows.Forms.Button();
            this.btnAddBids = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEventStatus
            // 
            this.cmbEventStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEventStatus.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEventStatus.FormattingEnabled = true;
            this.cmbEventStatus.Items.AddRange(new object[] {
            "Planning",
            "Ongoing",
            "Finished"});
            this.cmbEventStatus.Location = new System.Drawing.Point(314, 447);
            this.cmbEventStatus.Name = "cmbEventStatus";
            this.cmbEventStatus.Size = new System.Drawing.Size(228, 34);
            this.cmbEventStatus.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(18, 447);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 46;
            this.label1.Text = "Event Status";
            // 
            // cmbEventType
            // 
            this.cmbEventType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEventType.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEventType.FormattingEnabled = true;
            this.cmbEventType.Items.AddRange(new object[] {
            "barMitzva",
            "batMitzva",
            "companyEvent",
            "generalEvent",
            "wedding"});
            this.cmbEventType.Location = new System.Drawing.Point(314, 369);
            this.cmbEventType.Name = "cmbEventType";
            this.cmbEventType.Size = new System.Drawing.Size(226, 34);
            this.cmbEventType.TabIndex = 3;
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(221, 657);
            this.back.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(218, 71);
            this.back.TabIndex = 8;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(473, 657);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(218, 71);
            this.btnCreate.TabIndex = 7;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // lblBudget
            // 
            this.lblBudget.AutoSize = true;
            this.lblBudget.BackColor = System.Drawing.Color.Transparent;
            this.lblBudget.Location = new System.Drawing.Point(26, 590);
            this.lblBudget.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblBudget.Name = "lblBudget";
            this.lblBudget.Size = new System.Drawing.Size(78, 26);
            this.lblBudget.TabIndex = 44;
            this.lblBudget.Text = "Budget";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.BackColor = System.Drawing.Color.Transparent;
            this.lblType.Location = new System.Drawing.Point(18, 372);
            this.lblType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(113, 26);
            this.lblType.TabIndex = 43;
            this.lblType.Text = "Event Type";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Location = new System.Drawing.Point(18, 222);
            this.name.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(56, 26);
            this.name.TabIndex = 41;
            this.name.Text = "Date";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Location = new System.Drawing.Point(18, 298);
            this.email.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(91, 26);
            this.email.TabIndex = 40;
            this.email.Text = "Location";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.BackColor = System.Drawing.Color.Transparent;
            this.ID.Location = new System.Drawing.Point(18, 102);
            this.ID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(33, 26);
            this.ID.TabIndex = 39;
            this.ID.Text = "ID";
            // 
            // txtBudget
            // 
            this.txtBudget.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBudget.Location = new System.Drawing.Point(314, 576);
            this.txtBudget.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtBudget.MaxLength = 20;
            this.txtBudget.Name = "txtBudget";
            this.txtBudget.Size = new System.Drawing.Size(228, 34);
            this.txtBudget.TabIndex = 6;
            this.txtBudget.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBudget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBudget_KeyPress);
            // 
            // txtLocation
            // 
            this.txtLocation.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.Location = new System.Drawing.Point(314, 298);
            this.txtLocation.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtLocation.MaxLength = 30;
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(558, 34);
            this.txtLocation.TabIndex = 2;
            // 
            // lblCaption
            // 
            this.lblCaption.AutoSize = true;
            this.lblCaption.Location = new System.Drawing.Point(131, -57);
            this.lblCaption.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(168, 26);
            this.lblCaption.TabIndex = 38;
            this.lblCaption.Text = "Create Employee";
            // 
            // txtEventId
            // 
            this.txtEventId.BackColor = System.Drawing.SystemColors.Window;
            this.txtEventId.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEventId.ForeColor = System.Drawing.Color.Black;
            this.txtEventId.Location = new System.Drawing.Point(314, 102);
            this.txtEventId.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtEventId.MaxLength = 20;
            this.txtEventId.Name = "txtEventId";
            this.txtEventId.Size = new System.Drawing.Size(228, 34);
            this.txtEventId.TabIndex = 0;
            this.txtEventId.TabStop = false;
            this.txtEventId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpEventDate
            // 
            this.dtpEventDate.CustomFormat = "dd/MM/yyyy";
            this.dtpEventDate.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEventDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEventDate.Location = new System.Drawing.Point(314, 227);
            this.dtpEventDate.Name = "dtpEventDate";
            this.dtpEventDate.Size = new System.Drawing.Size(226, 34);
            this.dtpEventDate.TabIndex = 1;
            // 
            // cmbEventTime
            // 
            this.cmbEventTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEventTime.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEventTime.FormattingEnabled = true;
            this.cmbEventTime.Items.AddRange(new object[] {
            "Morning",
            "Afternoon",
            "Evening"});
            this.cmbEventTime.Location = new System.Drawing.Point(314, 515);
            this.cmbEventTime.Name = "cmbEventTime";
            this.cmbEventTime.Size = new System.Drawing.Size(228, 34);
            this.cmbEventTime.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(18, 515);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 26);
            this.label2.TabIndex = 49;
            this.label2.Text = "Event Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(18, 162);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 26);
            this.label3.TabIndex = 50;
            this.label3.Text = "Customer Phone";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNumber.Location = new System.Drawing.Point(314, 167);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtPhoneNumber.MaxLength = 10;
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(228, 34);
            this.txtPhoneNumber.TabIndex = 51;
            this.txtPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNumber_KeyPress);
            // 
            // newEvent
            // 
            this.newEvent.AutoSize = true;
            this.newEvent.BackColor = System.Drawing.Color.Transparent;
            this.newEvent.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newEvent.Location = new System.Drawing.Point(362, 31);
            this.newEvent.Name = "newEvent";
            this.newEvent.Size = new System.Drawing.Size(86, 34);
            this.newEvent.TabIndex = 52;
            this.newEvent.Text = "Event";
            this.newEvent.Click += new System.EventHandler(this.newEvent_Click);
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.AllowUserToResizeColumns = false;
            this.dgvOrders.AllowUserToResizeRows = false;
            this.dgvOrders.BackgroundColor = System.Drawing.Color.White;
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.ColumnHeadersVisible = false;
            this.dgvOrders.Location = new System.Drawing.Point(618, 71);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.RowHeadersVisible = false;
            this.dgvOrders.RowHeadersWidth = 51;
            this.dgvOrders.RowTemplate.Height = 24;
            this.dgvOrders.Size = new System.Drawing.Size(568, 190);
            this.dgvOrders.TabIndex = 55;
            this.dgvOrders.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOrders_CellDoubleClick);
            this.dgvOrders.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvOrders_CellFormatting);
            // 
            // btnEmergency
            // 
            this.btnEmergency.BackColor = System.Drawing.Color.DarkRed;
            this.btnEmergency.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEmergency.Location = new System.Drawing.Point(1018, 657);
            this.btnEmergency.Name = "btnEmergency";
            this.btnEmergency.Size = new System.Drawing.Size(182, 73);
            this.btnEmergency.TabIndex = 56;
            this.btnEmergency.Text = "Emergency";
            this.btnEmergency.UseVisualStyleBackColor = false;
            this.btnEmergency.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAddBids
            // 
            this.btnAddBids.Location = new System.Drawing.Point(786, 658);
            this.btnAddBids.Name = "btnAddBids";
            this.btnAddBids.Size = new System.Drawing.Size(202, 71);
            this.btnAddBids.TabIndex = 58;
            this.btnAddBids.Text = "Bids";
            this.btnAddBids.UseVisualStyleBackColor = true;
            this.btnAddBids.Click += new System.EventHandler(this.btnAddBids_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::GROUP30.Properties.Resources.red_carpet;
            this.pictureBox2.Location = new System.Drawing.Point(296, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(59, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 54;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.latizea;
            this.pictureBox1.Location = new System.Drawing.Point(1095, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(131, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // frmCreateEvent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::GROUP30.Properties.Resources._5631800;
            this.ClientSize = new System.Drawing.Size(1238, 772);
            this.Controls.Add(this.btnAddBids);
            this.Controls.Add(this.btnEmergency);
            this.Controls.Add(this.dgvOrders);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.newEvent);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbEventTime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpEventDate);
            this.Controls.Add(this.cmbEventStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbEventType);
            this.Controls.Add(this.back);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.lblBudget);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.name);
            this.Controls.Add(this.email);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.txtBudget);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.lblCaption);
            this.Controls.Add(this.txtEventId);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmCreateEvent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Event";
            this.Load += new System.EventHandler(this.frmCreateEvent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbEventStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbEventType;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblBudget;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.TextBox txtBudget;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label lblCaption;
        private System.Windows.Forms.TextBox txtEventId;
        private System.Windows.Forms.DateTimePicker dtpEventDate;
        private System.Windows.Forms.ComboBox cmbEventTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label newEvent;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.Button btnEmergency;
        private System.Windows.Forms.Button btnAddBids;
    }
}