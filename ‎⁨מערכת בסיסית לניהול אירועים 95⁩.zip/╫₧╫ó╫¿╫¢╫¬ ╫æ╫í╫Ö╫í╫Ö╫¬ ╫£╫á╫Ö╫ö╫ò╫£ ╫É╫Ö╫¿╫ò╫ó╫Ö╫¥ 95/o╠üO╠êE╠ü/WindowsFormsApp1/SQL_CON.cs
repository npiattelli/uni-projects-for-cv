﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;//חשוב!
using System.Windows.Forms;//עבור ההודעות!
using System.Data;
using System.Data.SqlTypes;

namespace GROUP30
{
    class SQL_CON
    {
        static SqlConnection conn;
        public static string ConnString = "";
        public SQL_CON()
        {
            conn = new SqlConnection(ConnString);//update this!!
        }

        public static Boolean execute_non_query(SqlCommand cmd, Boolean showDefaultMsg=true )
        {
            Boolean _returnVal = false;
            conn = new SqlConnection(ConnString);
            try
            {
                // open a connection object
                conn.Open();
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                _returnVal = true;
                if (showDefaultMsg) { MessageBox.Show(" השאילתה בוצעה בהצלחה", "המשך", MessageBoxButtons.OK); }
            }
            catch (SqlException exSql)
            {
                MessageBox.Show(exSql.Message, "המשך", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בביצוע השאילתה", "המשך", MessageBoxButtons.OK);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return _returnVal;
        }
        public static SqlDataReader execute_query(SqlCommand cmd)
        {
            conn = new SqlConnection(ConnString);
            try
            {
                // open a connection object
                conn.Open();
                cmd.Connection = conn;
                SqlDataReader READER = cmd.ExecuteReader();
                return READER;
            }
            catch (SqlException exSql)
            {
                MessageBox.Show(exSql.Message, "המשך", MessageBoxButtons.OK);
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בביצוע השאילתה", "המשך", MessageBoxButtons.OK);
                return null;
            }


        }
        public static object ToDBNull<T>(T Value)
        {
            try
            {
                if (Value == null)
                    return DBNull.Value;
                else
                {
                    if (Value.GetType() == typeof(DateTime))
                    {
                        if ((DateTime)(object)Value == DateTime.MinValue)
                            return DBNull.Value;
                        if ((DateTime)(object)Value < SqlDateTime.MinValue)
                            return DBNull.Value;
                        return Value; //DateTime.ParseExact(Value.ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                    return Value;
                }
            }
            catch (Exception)
            {
                return DBNull.Value;
            }
        }

    }


}

