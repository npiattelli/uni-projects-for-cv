
public class BurmeseTurtle extends IntelligentTurtle{

	public void draw (int sides, double size) {  // draw a polygon

		double probability = Math.random();
		if (probability <= 0.5) {
			int SumOfdeg = (sides - 2)*180; //Calculate the sum of degrees in a polygon
			int SizeOfangle = SumOfdeg/sides; //Calculate each angle in a polygon
			tailDown();
			for(int i=0; i<sides-1; i++) { //draws the polygon

				moveForward(size);
				turnRight(180-SizeOfangle);
			}
			hide();
		}
		else {
			super.draw(sides, 18);
		}
	}
}
