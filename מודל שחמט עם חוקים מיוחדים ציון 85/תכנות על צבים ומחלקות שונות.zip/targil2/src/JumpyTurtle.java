
public class JumpyTurtle extends IntelligentTurtle{

	public void moveForward (double distance) {
		int i = 0;
		distance = (int)(distance/4);
		while (i <distance) {
			tailDown();
			super.moveForward(4);
			i ++;
			tailUp();
			super.moveForward(4);
			i ++;
		}
	}
	public void moveWithOutJumping (double dis) {
		super.moveForward(dis);
	}
}

