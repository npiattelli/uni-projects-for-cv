﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    class Payment
    {
        public int paymentID { get; set; }
        public DateTime paymentDate { get; set; }
        public string paymentType { get; set; }
        public string paymentStatus { get; set; }
        public string cardnumber { get; set; }
        public int cardvaliditymonth { get; set; }
        public int cardvalidityyear { get; set; }
        public string cardcvv { get; set; }
        public string orderID { get; set; }
        public string isValid()
        {
            if (this.cardnumber.Length != 12 ) { return "Invalid Card Number"; }
            if (!(this.cardvaliditymonth >= 1 && this.cardvaliditymonth <= 12 && this.cardvalidityyear >= 2023))
            {
                return "Card expired";
            }
            if (this.cardcvv.Length <3 || this.cardcvv.Length>4) { return "Invalid CCV"; }

            return "";

        }
        public static Boolean CreatePayment(Payment payment)
        {

            SqlCommand cmd = new SqlCommand("add_Paymment");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@paymentType", payment.paymentType);
            cmd.Parameters.AddWithValue("@CardNumber", payment.cardnumber);
            cmd.Parameters.AddWithValue("@cardValidityMonth", payment.cardvaliditymonth);
            cmd.Parameters.AddWithValue("@cardValidityYear", payment.cardvalidityyear);
            cmd.Parameters.AddWithValue("@cardCVV", payment.cardcvv);
            cmd.Parameters.AddWithValue("@orderID", payment.orderID);
            return SQL_CON.execute_non_query(cmd,false);
        }
        public static Boolean cancelpayment(string paymentID)
        {
            SqlCommand cmd = new SqlCommand("cancel_Paymment");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@paymetID", paymentID);
            return SQL_CON.execute_non_query(cmd, false);
        }
    }
}
