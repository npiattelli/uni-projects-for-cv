
public class Dog extends Mamal {
	public boolean isStuck;

	public Dog(boolean isPlayerMamal) {
		super(isPlayerMamal);
	}

	@Override
	public boolean move(Cell[][] board, String move,boolean isPlayerMove) {
		int toRow = (move.charAt(0))-'0'-1;
		int toColumn = (move.charAt(1))-'0'-1;
		int fromRow=(move.charAt(3))-'0'-1;
		int fromColumn = (move.charAt(4))-'0'-1;


		if(!checkInBounds (board,toRow,toColumn,fromRow,fromColumn)) {
			return false;
		}


		Cell toCell = board[toRow][toColumn],fromCell = board[fromRow][fromColumn];
		int avgColumn = ( toColumn + fromColumn)/2;
		int avgRow = ( toRow + fromRow)/2;
		Cell eatenPlace = board[avgRow][avgColumn];
		if (fromCell.isEmpty() || !fromCell.getMamal().isMine(isPlayerMove) ||!toCell.isEmpty()) {
			return false;
		}

		if (!moveIsValid (eatenPlace, toRow, toColumn, fromRow, fromColumn , isPlayerMove)) {
			return false;
		}
		//			check here if the move is valid dog move, or valid dog eating move before moving the dog! 
		moveMamal(board,toRow,toColumn,fromRow,fromColumn);
		return true;
	}



	//checks if the dog ate a mamal on the recent move
	//	private boolean hasEaten(Cell [][] board, int toRow,int toColumn,int fromRow,int fromColumn) {
	//		return false;
	//	}
	//	
	private void stuck() {
		this.isStuck=true;
	}

	public String toString() {
		String id;
		if(isPlayerMamal) 
			id = "1" ;
		else
			id ="2";
		return "D"+ id;
	}
	private boolean moveIsValid (Cell eatenPlace, int toRow, int toColumn,int fromRow,int fromColumn , boolean isPlayerMove) {
		int fromUpdateTurn = fromRow - 1;
		int fromUpdateEatingTurn = fromRow - 2;
		if (!isPlayerMove) {
			fromUpdateTurn = fromRow + 1;
			fromUpdateEatingTurn = fromRow + 2;
		}
		if (toColumn == fromColumn || toRow == fromRow ) {
			return false;
		}
		if( fromUpdateTurn != toRow) {
			if (!(fromUpdateEatingTurn == toRow && (fromColumn + 2 == toColumn || fromColumn - 2 == toColumn )) ) {
				return false;
			}
			if ( (toRow == 0 && isPlayerMove ) || (toRow == 7 && !isPlayerMove )) {
				stuck();
			}
			if (!eatenPlace.isEmpty() && !eatenPlace.getMamal().isMine(isPlayerMove) ) {
				eatenPlace.clear();
				return true;
			}
			else {
				return false;
			}
		}
		if(fromColumn + 1 != toColumn && fromColumn - 1 != toColumn) {
			return false;
		}
		return true;
	}

	public boolean drawPiece (Cell[][] board, int fromRow, int fromColumn) {

		int[] deltafromRow = {1, 1, 2, 2};
		int[] deltafromColumn = {1, -1, 2, -2};
		int k;

		for(k=0; k<4; k++) {
			if(fromRow+deltafromRow[k] > 7 || fromColumn+deltafromColumn[k] > 7)
				continue;
			if(fromRow+deltafromRow[k] < 0 || fromColumn+deltafromColumn[k] < 0)
				continue;
			if(board[fromRow+deltafromRow[k]][fromColumn+deltafromColumn[k]].isEmpty())
				return false;
		}
		return true;
	}

	public boolean canEat (Cell[][] board, int fromRow, int fromColumn) {
		int[] deltafromRow = {2, 2};
		int[] deltafromColumn = { 2, -2};
		int k;
		for(k=0; k<2; k++) {
			int toRow = fromRow+deltafromRow[k];
			int toColumn = fromColumn+deltafromColumn[k];
			if(fromRow+deltafromRow[k] > 7 || fromColumn+deltafromColumn[k] > 7)
				continue;
			if(fromRow+deltafromRow[k] < 0 || fromColumn+deltafromColumn[k] < 0)
				continue;
			if(board[toRow][toColumn].isEmpty() && ((board[toRow-1][toColumn-1].getMamal().isPlayerMamal) || (board[toRow][toColumn+1].getMamal().isPlayerMamal))){
				return true;
			}
		}
		return false;
	}
	public boolean moveRange(int row,int col) {
		return((row == -1||row == 1) && (col == -1 || col == 1));
	}
}


