import Turtle.*;

public class DrunkTurtle extends Turtle{

	public void moveForward (double x) {  
		double randNumber = Math.random(); // Go forward a random distance between 0 to x
		double randMove = (x+1) * randNumber; // Choose a random number between 0 and x
		super.moveForward(randMove);

		randNumber = Math.random();  // Turns right in a in a probability of 45%
		if (randNumber <= 0.45) {
			super.turnRight(90);
		}
		randNumber = Math.random();		
		if (randNumber <= 0.35) {
			super.turnRight(180);

			randNumber = Math.random(); 
			randMove = (x+1) * randNumber; // Choose a new random number between 0 and x
			super.moveForward(randMove);
		}
		else {
			randNumber = Math.random(); 
			randMove = (x+1) * randNumber; // Choose a new random number between 0 and x
			super.moveForward(randMove);
		}	
	}
	public void turnLeft(int y) {
		int randomY = (int)(Math.random()*((1.5*y)+1));
		super.turnLeft(randomY);
	}
	public void turnRight(int y) {
		int randomY = (int)(Math.random()*((1.5*y)+1));
		super.turnRight(randomY);
	}
	
	
	public void moveSober(double dis) {
		super.moveForward(dis);
	}
	public void turnLeftSober(int x) {
		super.turnLeft(x);
	}
	public void turnRightSober(int x) {
		super.turnRight(x);
	}

}