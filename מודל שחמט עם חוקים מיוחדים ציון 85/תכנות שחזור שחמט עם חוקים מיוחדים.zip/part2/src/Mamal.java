

public abstract class Mamal {

	protected boolean isPlayerMamal;


	public Mamal (boolean isPlayerMamal) {
		this.isPlayerMamal = isPlayerMamal;
	}


	public boolean getIsPlayerMamal () {
		return this.isPlayerMamal;
	}


	public abstract boolean move(Cell [][] board , String move,boolean isPlayerMove) ;

	public boolean isMine(boolean isPlayerMove) {
		return isPlayerMamal == isPlayerMove;
	}


	public boolean checkInBounds (Cell [][] board, int toRow, int toColumn,int fromRow,int fromColumn) {
		int len = board.length;
		return inBound(toRow,len) && inBound(toColumn,len) && inBound(fromRow,len) && inBound(fromColumn,len);

	}

	private boolean inBound(int num,int len) {
		return num>=0 && num<=len;
	}

	protected void moveMamal(Cell[][] board, int toRow, int toColumn, int fromRow, int fromColumn) {
		board[toRow][toColumn].setMamal(this);
		board[fromRow][fromColumn].clear();
	}
	public abstract boolean drawPiece(Cell[][] board, int fromRow, int fromCollumn) ;

	public abstract boolean moveRange(int row,int col);
}

