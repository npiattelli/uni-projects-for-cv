﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class emergency_Form : Form
    {
        public emergency_Form()
        {
            InitializeComponent();
        }

        private void cmbEventType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbSupplierType.Text))
            {
                dgvSuppliers.DataSource = null;
                return;
            }
            Supplier supplier = new Supplier();
            supplier.SupplierType = cmbSupplierType.Text; // (suplierType)Enum.Parse(typeof(suplierType), cmbSupplierType.Text);
            dgvSuppliers.ColumnHeadersVisible = true;
            dgvSuppliers.AutoGenerateColumns = false;
            dgvSuppliers.Columns.Clear();
            dgvSuppliers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSuppliers.Columns.Add("supplierName", "Name");
            dgvSuppliers.Columns["supplierName"].DataPropertyName = "supplierName";
            dgvSuppliers.Columns["supplierName"].Width = 100;
            dgvSuppliers.Columns.Add("phoneNumber", "phoneNumber");
            dgvSuppliers.Columns["phoneNumber"].DataPropertyName = "phoneNumber";
            dgvSuppliers.Columns["phoneNumber"].Width = 100;
            dgvSuppliers.DataSource = null;
            dgvSuppliers.DataSource = Supplier.get_Suppliers(supplier);
            if (dgvSuppliers.Rows.Count == 0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void emergency_Form_Load(object sender, EventArgs e)
        {

        }

        private void cmbSupplierType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbSupplierType_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void send_sms_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SMS's where sent to all our emergency contacts", "המשך", MessageBoxButtons.OK);
            this.Close();
        }

        private void dgvSuppliers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
