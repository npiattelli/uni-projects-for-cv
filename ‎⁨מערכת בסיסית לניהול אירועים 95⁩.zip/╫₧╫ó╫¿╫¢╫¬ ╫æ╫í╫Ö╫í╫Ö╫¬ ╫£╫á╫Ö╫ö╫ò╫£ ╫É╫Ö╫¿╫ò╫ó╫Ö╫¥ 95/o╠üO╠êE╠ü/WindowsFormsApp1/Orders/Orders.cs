﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30

{
    public class Order
    {
        public string orderID { get; set; }
        public DateTime orderDate { get; set; }
        public string orderDescription { get; set; }
        public DateTime dueDate { get; set; }
        public double orderPrice { get; set; }
        public Boolean isPaid { get; set; }
        public string eventID { get; set; }
        public string supplierID { get; set; }
        public string supplierName { get; set; } = "";
        public string paymentID { get; set; } = "";
        public string SupplierType { get; set; } = "";

        public static Boolean Create_Order(Order obj)
        {
            SqlCommand c = new SqlCommand("add_Order");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            //c.Parameters.AddWithValue("@orderID", obj.orderID);
            c.Parameters.AddWithValue("@orderDate", obj.orderDate);
            c.Parameters.AddWithValue("@dueDate", obj.dueDate);
            c.Parameters.AddWithValue("@orderDescription", obj.orderDescription.ToString());
            c.Parameters.AddWithValue("@orderPrice", obj.orderPrice);
           // c.Parameters.AddWithValue("@isPaid", obj.isPaid);
            c.Parameters.AddWithValue("@eventID", obj.eventID);
            c.Parameters.AddWithValue("@supplierID", obj.supplierID);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Update_Order(Order obj)
        {
            SqlCommand c = new SqlCommand("update_Order");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@orderID", obj.orderID);
            c.Parameters.AddWithValue("@orderDate", obj.orderDate);
            c.Parameters.AddWithValue("@dueDate", obj.dueDate);
            c.Parameters.AddWithValue("@orderDescription", obj.orderDescription.ToString());
            c.Parameters.AddWithValue("@orderPrice", obj.orderPrice);
             c.Parameters.AddWithValue("@isPaid", obj.isPaid);
            c.Parameters.AddWithValue("@eventID", obj.eventID);
            c.Parameters.AddWithValue("@supplierID", obj.supplierID); return SQL_CON.execute_non_query(c, false);
        }
        public static List<Order> get_Orders(Order obj)
        {
            SqlCommand c = new SqlCommand("Get_Orders");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@orderID", SQL_CON.ToDBNull( obj.orderID));
            c.Parameters.AddWithValue("@eventID", SQL_CON.ToDBNull(obj.eventID));
            c.Parameters.AddWithValue("@supplierID", SQL_CON.ToDBNull(obj.supplierID));
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Order> _list = new List<Order>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Order s = new Order()
                    {
                        orderID = rdr["orderID"].ToString(),
                        eventID = rdr["eventID"].ToString(),
                        supplierID = rdr["supplierID"].ToString(),
                        orderDescription = rdr["orderDescription"].ToString(),
                        orderDate = DateTime.Parse(rdr["orderDate"].ToString()),
                        dueDate = DateTime.Parse(rdr["dueDate"].ToString()),
                        orderPrice = double.Parse(rdr["orderPrice"].ToString()),
                        isPaid = (rdr["isPaid"].ToString().ToLower()=="true"),
                        supplierName = rdr["supplierName"].ToString(),
                        SupplierType = rdr["SUPPLIER_TYPE"].ToString(),
                        paymentID = rdr["paymetID"].ToString(),
                    };
                    _list.Add(s);
                }
            }
            return _list;
        }


    }
}
