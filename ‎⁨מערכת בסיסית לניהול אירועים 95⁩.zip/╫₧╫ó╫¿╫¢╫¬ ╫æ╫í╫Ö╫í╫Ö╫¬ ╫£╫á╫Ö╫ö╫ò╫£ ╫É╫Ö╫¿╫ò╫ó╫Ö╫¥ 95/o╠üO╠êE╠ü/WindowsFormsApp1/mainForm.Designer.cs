﻿namespace GROUP30
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnEmployees = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.viewEvent = new System.Windows.Forms.Button();
            this.plannerArea = new System.Windows.Forms.Label();
            this.employeesArea = new System.Windows.Forms.Label();
            this.customersArea = new System.Windows.Forms.Label();
            this.pbEmployeesArea = new System.Windows.Forms.PictureBox();
            this.pbEmployees = new System.Windows.Forms.PictureBox();
            this.pbCustomerArea = new System.Windows.Forms.PictureBox();
            this.pbPlannersArea = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.logo = new System.Windows.Forms.PictureBox();
            this.pbCustomers = new System.Windows.Forms.PictureBox();
            this.pbEvents = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pbSuppliers = new System.Windows.Forms.PictureBox();
            this.backPA = new System.Windows.Forms.Button();
            this.backCA = new System.Windows.Forms.Button();
            this.pnlPlannersArea = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlCustomersArea = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployeesArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomerArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlannersArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSuppliers)).BeginInit();
            this.pnlPlannersArea.SuspendLayout();
            this.pnlCustomersArea.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSupplier
            // 
            this.btnSupplier.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupplier.Location = new System.Drawing.Point(76, 143);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(100, 33);
            this.btnSupplier.TabIndex = 0;
            this.btnSupplier.Text = "Suppliers";
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.Location = new System.Drawing.Point(72, 74);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(98, 33);
            this.btnPayment.TabIndex = 1;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Visible = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // btnCustomer
            // 
            this.btnCustomer.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.Location = new System.Drawing.Point(76, 62);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(100, 33);
            this.btnCustomer.TabIndex = 2;
            this.btnCustomer.Text = "Customers";
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // btnEmployees
            // 
            this.btnEmployees.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployees.Location = new System.Drawing.Point(76, 102);
            this.btnEmployees.Name = "btnEmployees";
            this.btnEmployees.Size = new System.Drawing.Size(100, 34);
            this.btnEmployees.TabIndex = 3;
            this.btnEmployees.Text = "Employees";
            this.btnEmployees.UseVisualStyleBackColor = true;
            this.btnEmployees.Click += new System.EventHandler(this.btnEmployees_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(76, 182);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 34);
            this.button1.TabIndex = 4;
            this.button1.Text = "Events";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(596, 397);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 34);
            this.button2.TabIndex = 5;
            this.button2.Text = "Exit ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // viewEvent
            // 
            this.viewEvent.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewEvent.Location = new System.Drawing.Point(72, 118);
            this.viewEvent.Margin = new System.Windows.Forms.Padding(2);
            this.viewEvent.Name = "viewEvent";
            this.viewEvent.Size = new System.Drawing.Size(98, 33);
            this.viewEvent.TabIndex = 13;
            this.viewEvent.Text = "View Event";
            this.viewEvent.UseVisualStyleBackColor = true;
            this.viewEvent.Click += new System.EventHandler(this.viewEvent_Click);
            // 
            // plannerArea
            // 
            this.plannerArea.AutoSize = true;
            this.plannerArea.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plannerArea.Location = new System.Drawing.Point(164, 146);
            this.plannerArea.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.plannerArea.Name = "plannerArea";
            this.plannerArea.Size = new System.Drawing.Size(120, 21);
            this.plannerArea.TabIndex = 15;
            this.plannerArea.Text = "planner\'s Area";
            // 
            // employeesArea
            // 
            this.employeesArea.AutoSize = true;
            this.employeesArea.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeesArea.Location = new System.Drawing.Point(309, 146);
            this.employeesArea.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.employeesArea.Name = "employeesArea";
            this.employeesArea.Size = new System.Drawing.Size(132, 21);
            this.employeesArea.TabIndex = 16;
            this.employeesArea.Text = "Employees Area";
            // 
            // customersArea
            // 
            this.customersArea.AutoSize = true;
            this.customersArea.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customersArea.Location = new System.Drawing.Point(14, 146);
            this.customersArea.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.customersArea.Name = "customersArea";
            this.customersArea.Size = new System.Drawing.Size(127, 21);
            this.customersArea.TabIndex = 17;
            this.customersArea.Text = "customers Area";
            // 
            // pbEmployeesArea
            // 
            this.pbEmployeesArea.Image = global::GROUP30.Properties.Resources.workers;
            this.pbEmployeesArea.Location = new System.Drawing.Point(318, 20);
            this.pbEmployeesArea.Margin = new System.Windows.Forms.Padding(2);
            this.pbEmployeesArea.Name = "pbEmployeesArea";
            this.pbEmployeesArea.Size = new System.Drawing.Size(112, 119);
            this.pbEmployeesArea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEmployeesArea.TabIndex = 22;
            this.pbEmployeesArea.TabStop = false;
            this.pbEmployeesArea.Tag = "2";
            this.pbEmployeesArea.Click += new System.EventHandler(this.pbArea_Click);
            // 
            // pbEmployees
            // 
            this.pbEmployees.Image = global::GROUP30.Properties.Resources.worker;
            this.pbEmployees.Location = new System.Drawing.Point(31, 102);
            this.pbEmployees.Margin = new System.Windows.Forms.Padding(2);
            this.pbEmployees.Name = "pbEmployees";
            this.pbEmployees.Size = new System.Drawing.Size(39, 32);
            this.pbEmployees.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEmployees.TabIndex = 21;
            this.pbEmployees.TabStop = false;
            this.pbEmployees.Click += new System.EventHandler(this.pbEmployees_Click);
            // 
            // pbCustomerArea
            // 
            this.pbCustomerArea.Image = global::GROUP30.Properties.Resources.male_customer;
            this.pbCustomerArea.Location = new System.Drawing.Point(29, 20);
            this.pbCustomerArea.Margin = new System.Windows.Forms.Padding(2);
            this.pbCustomerArea.Name = "pbCustomerArea";
            this.pbCustomerArea.Size = new System.Drawing.Size(101, 112);
            this.pbCustomerArea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCustomerArea.TabIndex = 20;
            this.pbCustomerArea.TabStop = false;
            this.pbCustomerArea.Tag = "0";
            this.pbCustomerArea.Click += new System.EventHandler(this.pbArea_Click);
            // 
            // pbPlannersArea
            // 
            this.pbPlannersArea.Image = global::GROUP30.Properties.Resources.manager;
            this.pbPlannersArea.Location = new System.Drawing.Point(169, 15);
            this.pbPlannersArea.Margin = new System.Windows.Forms.Padding(2);
            this.pbPlannersArea.Name = "pbPlannersArea";
            this.pbPlannersArea.Size = new System.Drawing.Size(122, 119);
            this.pbPlannersArea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlannersArea.TabIndex = 18;
            this.pbPlannersArea.TabStop = false;
            this.pbPlannersArea.Tag = "1";
            this.pbPlannersArea.Click += new System.EventHandler(this.pbArea_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::GROUP30.Properties.Resources.confetti;
            this.pictureBox5.Location = new System.Drawing.Point(26, 118);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(41, 33);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.Color.Transparent;
            this.logo.Image = global::GROUP30.Properties.Resources.latizea;
            this.logo.Location = new System.Drawing.Point(217, 20);
            this.logo.Margin = new System.Windows.Forms.Padding(2);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(237, 91);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 12;
            this.logo.TabStop = false;
            // 
            // pbCustomers
            // 
            this.pbCustomers.BackColor = System.Drawing.Color.Transparent;
            this.pbCustomers.Image = global::GROUP30.Properties.Resources.identity_card;
            this.pbCustomers.Location = new System.Drawing.Point(31, 62);
            this.pbCustomers.Name = "pbCustomers";
            this.pbCustomers.Size = new System.Drawing.Size(41, 33);
            this.pbCustomers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCustomers.TabIndex = 10;
            this.pbCustomers.TabStop = false;
            this.pbCustomers.Click += new System.EventHandler(this.pbCustomers_Click);
            // 
            // pbEvents
            // 
            this.pbEvents.BackColor = System.Drawing.Color.Transparent;
            this.pbEvents.Image = global::GROUP30.Properties.Resources.confetti;
            this.pbEvents.Location = new System.Drawing.Point(31, 182);
            this.pbEvents.Name = "pbEvents";
            this.pbEvents.Size = new System.Drawing.Size(39, 34);
            this.pbEvents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEvents.TabIndex = 9;
            this.pbEvents.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::GROUP30.Properties.Resources.cash_payment;
            this.pictureBox2.Location = new System.Drawing.Point(26, 73);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(41, 33);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pbSuppliers
            // 
            this.pbSuppliers.Image = global::GROUP30.Properties.Resources.fd9968106c11325a22abb735a741b7c1;
            this.pbSuppliers.Location = new System.Drawing.Point(31, 143);
            this.pbSuppliers.Name = "pbSuppliers";
            this.pbSuppliers.Size = new System.Drawing.Size(41, 33);
            this.pbSuppliers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSuppliers.TabIndex = 7;
            this.pbSuppliers.TabStop = false;
            // 
            // backPA
            // 
            this.backPA.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backPA.Location = new System.Drawing.Point(61, 237);
            this.backPA.Margin = new System.Windows.Forms.Padding(2);
            this.backPA.Name = "backPA";
            this.backPA.Size = new System.Drawing.Size(68, 31);
            this.backPA.TabIndex = 23;
            this.backPA.Text = "back";
            this.backPA.UseVisualStyleBackColor = true;
            this.backPA.Click += new System.EventHandler(this.backPA_Click);
            // 
            // backCA
            // 
            this.backCA.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backCA.Location = new System.Drawing.Point(55, 186);
            this.backCA.Margin = new System.Windows.Forms.Padding(2);
            this.backCA.Name = "backCA";
            this.backCA.Size = new System.Drawing.Size(69, 28);
            this.backCA.TabIndex = 24;
            this.backCA.Text = "back";
            this.backCA.UseVisualStyleBackColor = true;
            this.backCA.Click += new System.EventHandler(this.backPA_Click);
            // 
            // pnlPlannersArea
            // 
            this.pnlPlannersArea.BackColor = System.Drawing.Color.Transparent;
            this.pnlPlannersArea.Controls.Add(this.label2);
            this.pnlPlannersArea.Controls.Add(this.viewEvent);
            this.pnlPlannersArea.Controls.Add(this.backCA);
            this.pnlPlannersArea.Controls.Add(this.btnPayment);
            this.pnlPlannersArea.Controls.Add(this.pictureBox2);
            this.pnlPlannersArea.Controls.Add(this.pictureBox5);
            this.pnlPlannersArea.Location = new System.Drawing.Point(8, 20);
            this.pnlPlannersArea.Margin = new System.Windows.Forms.Padding(2);
            this.pnlPlannersArea.Name = "pnlPlannersArea";
            this.pnlPlannersArea.Size = new System.Drawing.Size(205, 223);
            this.pnlPlannersArea.TabIndex = 25;
            this.pnlPlannersArea.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlPlannersArea_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 27);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 31);
            this.label2.TabIndex = 25;
            this.label2.Text = "Customers Area";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pnlCustomersArea
            // 
            this.pnlCustomersArea.BackColor = System.Drawing.Color.Transparent;
            this.pnlCustomersArea.Controls.Add(this.label1);
            this.pnlCustomersArea.Controls.Add(this.btnSupplier);
            this.pnlCustomersArea.Controls.Add(this.btnCustomer);
            this.pnlCustomersArea.Controls.Add(this.backPA);
            this.pnlCustomersArea.Controls.Add(this.btnEmployees);
            this.pnlCustomersArea.Controls.Add(this.button1);
            this.pnlCustomersArea.Controls.Add(this.pbEmployees);
            this.pnlCustomersArea.Controls.Add(this.pbSuppliers);
            this.pnlCustomersArea.Controls.Add(this.pbEvents);
            this.pnlCustomersArea.Controls.Add(this.pbCustomers);
            this.pnlCustomersArea.Location = new System.Drawing.Point(458, 11);
            this.pnlCustomersArea.Margin = new System.Windows.Forms.Padding(2);
            this.pnlCustomersArea.Name = "pnlCustomersArea";
            this.pnlCustomersArea.Size = new System.Drawing.Size(204, 281);
            this.pnlCustomersArea.TabIndex = 26;
            this.pnlCustomersArea.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlCustomersArea_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 31);
            this.label1.TabIndex = 24;
            this.label1.Text = "Planner\'s Area";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Transparent;
            this.pnlMain.Controls.Add(this.pbPlannersArea);
            this.pnlMain.Controls.Add(this.plannerArea);
            this.pnlMain.Controls.Add(this.employeesArea);
            this.pnlMain.Controls.Add(this.pbEmployeesArea);
            this.pnlMain.Controls.Add(this.customersArea);
            this.pnlMain.Controls.Add(this.pbCustomerArea);
            this.pnlMain.Location = new System.Drawing.Point(102, 140);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(2);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(469, 175);
            this.pnlMain.TabIndex = 27;
            // 
            // mainForm
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::GROUP30.Properties.Resources._5631800;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(669, 435);
            this.Controls.Add(this.pnlPlannersArea);
            this.Controls.Add(this.pnlCustomersArea);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.button2);
            this.MaximumSize = new System.Drawing.Size(686, 480);
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Letizia Events";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.mainForm_FormClosed);
            this.Load += new System.EventHandler(this.mainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployeesArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEmployees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomerArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlannersArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEvents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSuppliers)).EndInit();
            this.pnlPlannersArea.ResumeLayout(false);
            this.pnlPlannersArea.PerformLayout();
            this.pnlCustomersArea.ResumeLayout(false);
            this.pnlCustomersArea.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnEmployees;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pbSuppliers;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pbEvents;
        private System.Windows.Forms.PictureBox pbCustomers;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button viewEvent;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label plannerArea;
        private System.Windows.Forms.Label employeesArea;
        private System.Windows.Forms.Label customersArea;
        private System.Windows.Forms.PictureBox pbPlannersArea;
        private System.Windows.Forms.PictureBox pbCustomerArea;
        private System.Windows.Forms.PictureBox pbEmployees;
        private System.Windows.Forms.PictureBox pbEmployeesArea;
        private System.Windows.Forms.Button backPA;
        private System.Windows.Forms.Button backCA;
        private System.Windows.Forms.Panel pnlPlannersArea;
        private System.Windows.Forms.Panel pnlCustomersArea;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}