﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmCancelPayment : Form
    {
        public string PaymentID {
            get { return txtPaymentID.Text; }
            set {
                txtPaymentID.Text = value;
                txtPaymentID.ReadOnly = true;
            }
        }
        public frmCancelPayment()
        {
            InitializeComponent();
            this.DialogResult = DialogResult.None;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPaymentID.Text)) { return; }
            if (Payment.cancelpayment(txtPaymentID.Text))
            {
                MessageBox.Show("Your payment cancelled successfully", "המשך", MessageBoxButtons.OK);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
            this.Close();
        }

        private void frmCancelPayment_Load(object sender, EventArgs e)
        {

        }

        private void ID_Click(object sender, EventArgs e)
        {

        }
    }
}
