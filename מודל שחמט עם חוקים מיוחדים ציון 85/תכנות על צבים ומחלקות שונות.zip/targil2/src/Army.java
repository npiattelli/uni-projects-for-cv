import java.util.Scanner;

import Turtle.*;


public class Army {


	public static void menu() {
		System.out.println("Choose the type of a turtle:\r\n"
				+ "1.	Simple\r\n"
				+ "2.	Intelligent\r\n"
				+ "3.	Drunk\r\n"
				+ "4.	Jumpy\r\n"
				+ "5.	Lazy\r\n"
				+ "6.	Burmese\r\n"
				+ "");

	}
	public static Turtle [] createTurtleArr () {
		final int size = 5;
		Turtle [] army = new Turtle [size];
		return army;
	}
	public static Turtle [] createArmy() {
		Scanner s = new Scanner(System.in);
		Turtle [] scarryArmy = createTurtleArr () ;
		for (int i = 0 ; i<scarryArmy.length ; i ++) {
			menu();
			System.out.println("choose your "+ (i+1) +" Turtle:");
			int typeOfTurtle = s.nextInt();
			if (typeOfTurtle == 1) {
				Turtle a = new Turtle();
				scarryArmy[i] = a;
			}
			else if (typeOfTurtle == 2) {
				Turtle b = new IntelligentTurtle();
				scarryArmy[i] = b;
			}
			else if (typeOfTurtle == 3) {
				Turtle c = new DrunkTurtle();
				scarryArmy[i] = c;
			}
			else if (typeOfTurtle == 4) {
				Turtle d  = new	JumpyTurtle();
				scarryArmy[i] = d;
			}
			else if (typeOfTurtle == 5) {
				Turtle e = new LazyTurtle();
				scarryArmy[i] = e;
			}
			else if  (typeOfTurtle == 6) {

				Turtle f  = new BurmeseTurtle();
				scarryArmy[i] = f;

			}
		}	
		System.out.println("ready for war!!!!!!!!!!!!");
		return scarryArmy;
	}

	public static void armyInPosition (Turtle [] army ) {
		for (int i = 0; i < army.length; i++) {
			if (army[i] instanceof DrunkTurtle ) {

				((DrunkTurtle) army[i]).show();
				((DrunkTurtle) army[i]).tailUp();
				((DrunkTurtle) army[i]).turnRightSober(90);
				((DrunkTurtle) army[i]).moveSober(120 * (i));
				((DrunkTurtle) army[i]).turnLeftSober(90);
				continue;
			}
			else if (army[i] instanceof JumpyTurtle) {

				((JumpyTurtle) army[i]).show();
				((JumpyTurtle) army[i]).tailUp();
				((JumpyTurtle) army[i]).turnRight(90);
				((JumpyTurtle) army[i]).moveWithOutJumping(120 * (i));
				((JumpyTurtle) army[i]).turnLeft(90);
				continue;
			}
			else if (army[i] instanceof BurmeseTurtle) {

				((BurmeseTurtle) army[i]).show();
				((BurmeseTurtle) army[i]).tailUp();
				((BurmeseTurtle) army[i]).turnRight(90);
				((BurmeseTurtle) army[i]).moveForward(120 * (i));
				((BurmeseTurtle) army[i]).turnLeft(90);
				continue;
			}

			else if (army[i] instanceof IntelligentTurtle) {

				((IntelligentTurtle) army[i]).show();
				((IntelligentTurtle) army[i]).tailUp();
				((IntelligentTurtle) army[i]).turnRight(90);
				((IntelligentTurtle) army[i]).moveForward(120 * (i));
				((IntelligentTurtle) army[i]).turnLeft(90);
				continue;
			}
			else if (army[i] instanceof LazyTurtle) {

				((LazyTurtle) army[i]).show();
				((LazyTurtle) army[i]).tailUp();
				((LazyTurtle) army[i]).turnRightSober(90);
				((LazyTurtle) army[i]).moveSober(120 * (i));
				((LazyTurtle) army[i]).turnLeftSober(90);
				continue;
			}
			else  {

				army[i].show();
				army[i].tailUp();
				army[i].turnRight(90);
				army[i].moveForward(120 * (i));
				army[i].turnLeft(90);
				continue;
			}
		}
	}
	public static void tailDown(Turtle[] army) {
		for(int i = 0;i< army.length ;i++) {
			army[i].tailDown();
		}
	}
	public static void armyTurnLeft(Turtle[] army) {
		final int degree = 40;
		for (int i = 0; i < army.length; i++) {
			army[i].turnLeft(degree);
		}
	}
	public static void armyGoForward65(Turtle[] army) {//start walking 
		final int length = 65;
		for (int i = 0; i < army.length; i++) {
			army[i].moveForward(length);
		}
	}

	public static void armyGoForward75(Turtle[] army) {//start walking 
		final int length = 75 ;
		for (int i = 0; i < army.length; i++) {
			army[i].moveForward(length);
		}
	}
	public static void hideArmy(Turtle[] army) {// hides the army
		for (int i = 0; i < army.length; i++) {
			army[i].hide();
		}
	}
	public static void smartTurtles (Turtle [] army) {

		final int sides = 6;
		final int size = 40 ;
		for (int i = 0; i < army.length; i++) {
			if (army[i] instanceof BurmeseTurtle) {
				((BurmeseTurtle) army[i]).draw(sides, size);
				continue;
			}
			else if (army[i] instanceof JumpyTurtle) {
				((JumpyTurtle) army[i]).draw(sides, size);
				continue;
			}
			else if (army[i] instanceof IntelligentTurtle) {
				((IntelligentTurtle) army[i]).draw(sides, size);
				continue;
			}
			else {
				continue;
			}
		}
	}
	public static void armyAttacks (Turtle [] army ) {
		armyInPosition(army);
		tailDown(army);
		armyGoForward65(army);
		armyTurnLeft(army);
		armyGoForward75(army);
		smartTurtles(army);
		hideArmy(army);
	}
	public static void main(String[] args) {
		Turtle [] army = createArmy();
		armyAttacks (army);
	}
}
