﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmAddBids : Form
    {
        private string m_EventID = "";
        public string EventID {
            get { return m_EventID;}
            set {
                m_EventID = value;
                refreshBids();
            }
        }
        public frmAddBids()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count==0 )
            {
                MessageBox.Show("Select Supplier.", "המשך", MessageBoxButtons.OK);
                cmbSupplierType.Focus();
                return;
            }
            double _price = 0;
            if (string.IsNullOrEmpty(txtPrice.Text) || !double.TryParse(txtPrice.Text, out _price ))
            {
                MessageBox.Show("Price required.", "המשך", MessageBoxButtons.OK);
                txtPrice.Focus();
                return;
            }
            SupplierBid _bid = new SupplierBid()
            {
                supplierID = dgvSuppliers.SelectedRows[0].Cells["supplierID"].Value.ToString(),
                details = txtDetails.Text,
                eventID= EventID,
                price = double.Parse(txtPrice.Text)
            };
            if (Event.addSupplierBid(_bid))
            {
                refreshBids();
            }
        }
        private void refreshBids()
        {
            dgvBids.AutoGenerateColumns = false;
            dgvBids.Columns.Clear();
            dgvBids.ColumnHeadersVisible = true;
            dgvBids.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBids.Columns.Add("supplierType", "Type");
            dgvBids.Columns["supplierType"].DataPropertyName = "SupplierTypeStr";
            dgvBids.Columns["supplierType"].Width = 200;
            dgvBids.Columns.Add("supplierName", "Name");
            dgvBids.Columns["supplierName"].DataPropertyName = "supplierName";
            dgvBids.Columns["supplierName"].Width = 300;
            dgvBids.Columns.Add("price", "Price");
            dgvBids.Columns["price"].DataPropertyName = "price";
            dgvBids.Columns["price"].Width = 150;
            dgvBids.DataSource = null;
            dgvBids.DataSource = Event.get_Bids(EventID);

        }
        private void cmbSupplierType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbSupplierType.Text))
            {
                dgvSuppliers.DataSource = null;
                return;
            }
            Supplier supplier = new Supplier();
            supplier.SupplierType = cmbSupplierType.Text; //(suplierType)Enum.Parse(typeof(suplierType), cmbSupplierType.Text);
            dgvSuppliers.ColumnHeadersVisible = true;

            dgvSuppliers.AutoGenerateColumns = false;
            dgvSuppliers.Columns.Clear();
            dgvSuppliers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSuppliers.Columns.Add("supplierID", "Id");
            dgvSuppliers.Columns["supplierID"].DataPropertyName = "supplierID";
            dgvSuppliers.Columns["supplierID"].Width = 150;
            dgvSuppliers.Columns.Add("supplierName", "Name");
            dgvSuppliers.Columns["supplierName"].DataPropertyName = "supplierName";
            dgvSuppliers.Columns["supplierName"].Width = 300;
            dgvSuppliers.DataSource = null;
            dgvSuppliers.DataSource = Supplier.get_Suppliers(supplier);
            if (dgvSuppliers.Rows.Count == 0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Event.GenerateOrders(EventID))
            {
                this.Close();
            }
        }

        private void optimal_supplier_Click(object sender, EventArgs e)
        {
            find_optimal_supplier form = new find_optimal_supplier();
            form.ShowDialog(this);
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void frmAddBids_Load(object sender, EventArgs e)
        {

        }
    }
}
