﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmEmployeeMain : Form
    {
        public frmEmployeeMain()
        {
            InitializeComponent();
        }

        private void frmEmployeeMain_Load(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            frmCreatingEmployee _frm = new frmCreatingEmployee();
            _frm.ShowDialog(this);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            frmSearchingEmployee SearchForm = new frmSearchingEmployee();
            SearchForm.ShowDialog(this);
        }


    }
}
