
public class Elephant extends Mamal {
	protected boolean isQueen;

	public Elephant(boolean isPlayerMamal) {
		super(isPlayerMamal);
	}
	public boolean getIsQueen () {
		return isQueen;
	}

	@Override
	public boolean move(Cell[][] board, String move,boolean isPlayerMove) {
		int toRow = (move.charAt(0))-'0'-1;
		int toColumn = (move.charAt(1))-'0'-1;
		int fromRow=(move.charAt(3))-'0'-1;
		int fromColumn = (move.charAt(4))-'0'-1;


		if(!checkInBounds (board,toRow,toColumn,fromRow,fromColumn)) {
			return false;
		}

		Cell toCell = board[toRow][toColumn],fromCell = board[fromRow][fromColumn];
		int avgColumn = ( toColumn + fromColumn)/2;
		int avgRow = ( toRow + fromRow)/2;
		Cell eatenPlace = board[avgRow][avgColumn];
		if (fromCell.isEmpty() || !fromCell.getMamal().isMine(isPlayerMove) ||!toCell.isEmpty()) {
			return false;
		}
		if (isQueen) {
			if (!moveIsQueenValid(eatenPlace, toRow, toColumn, fromRow, fromColumn , isPlayerMove)) {
				return false;
			}
		}
		else if (!moveIsValid (eatenPlace, toRow, toColumn, fromRow, fromColumn , isPlayerMove)) {
			return false;
		}
		//			check here if the move is valid Elephant move, or valid Elephant eating move before moving the Elephant! 
		moveMamal(board,toRow,toColumn,fromRow,fromColumn);
		return true;
	}

	private void queen() {
		this.isQueen=true;
	}

	public String toString() {
		String id;
		if(isPlayerMamal) 
			id = "1" ;
		else
			id ="2";
		if (isQueen) {
			return "E"+ id + "Q";
		}
		return "E"+ id;
	}

	private boolean moveIsValid (Cell eatenPlace, int toRow, int toColumn,int fromRow,int fromColumn , boolean isPlayerMove) {
		int fromUpdateTurn = fromRow - 2;
		int fromUpdateEatingTurn = fromRow - 2;
		int absRow = Math.abs((fromRow)-(toRow)) ;
		int absCol = Math.abs((fromColumn)-(toColumn));
		if (!isPlayerMove) {
			fromUpdateTurn = fromRow + 2;
			fromUpdateEatingTurn = fromRow + 2;
		}
		if (absCol !=2 ) {
			return false;
		}
		if( fromUpdateTurn != toRow) {
			return false;
		}

		if ( (toRow == 0 && isPlayerMove ) || (toRow == 7 && !isPlayerMove )) {
			queen();
		}
		if (!eatenPlace.isEmpty() && !eatenPlace.getMamal().isMine(isPlayerMove) ) {
			eatenPlace.clear();
		}
		if (!eatenPlace.isEmpty() && eatenPlace.getMamal().isMine(isPlayerMove) ) {
			return false;
		}
		return true;
	}

	private boolean moveIsQueenValid (Cell eatenPlace, int toRow, int toColumn,int fromRow,int fromColumn , boolean isPlayerMove) {

		int absRow = Math.abs((fromRow)-(toRow)) ;
		int absCol = Math.abs((fromColumn)-(toColumn));

		if (absCol !=2 ) {
			return false;
		}
		if( absRow != 2) {
			return false;
		}

		if (!eatenPlace.isEmpty() && !eatenPlace.getMamal().isMine(isPlayerMove) ) {
			eatenPlace.clear();
		}
		if (!eatenPlace.isEmpty() && eatenPlace.getMamal().isMine(isPlayerMove) ) {
			return false;
		}
		return true;


	}

	private boolean normalOrQueen() {
		if (this.isQueen) {
			return true;
		}
		return false;
	}
	public static boolean DrawQeenEli(Cell[][] board, int fromRow, int fromColumn) {

		int[] deltafromRow = { 2, 2, -2, -2};
		int[] deltafromColumn = { 2, -2, 2, -2};
		int k;

		for(k=0; k<4; k++) {
			if(fromRow+deltafromRow[k] > 7 || fromColumn+deltafromColumn[k] > 7)
				continue;
			if(fromRow+deltafromRow[k] < 0 || fromColumn+deltafromColumn[k] < 0)
				continue;
			if(board[fromRow+deltafromRow[k]][fromColumn+deltafromColumn[k]].isEmpty())
				return false;
		}

		return true;
	}
	public static boolean DrawEli(Cell[][] board, int fromRow, int fromColumn) {

		int[] deltafromRow = { 2, 2};
		int[] deltafromColumn = { 2, -2};
		int k;

		for(k=0; k<2; k++) {
			if(fromRow+deltafromRow[k] > 7 || fromColumn+deltafromColumn[k] > 7)
				continue;
			if(fromRow+deltafromRow[k] < 0 || fromColumn+deltafromColumn[k] < 0)
				continue;
			if(board[fromRow+deltafromRow[k]][fromColumn+deltafromColumn[k]].isEmpty())
				return false;
		}
		return true;
	}
	public boolean drawPiece (Cell[][] board, int fromRow, int fromColumn) {

		if(((Elephant)(board[fromRow][fromColumn]).getMamal()).getIsQueen()) {
			if(DrawQeenEli(board, fromRow,  fromColumn)) {
				return true;
			}
		}
		if (DrawEli(board,fromRow,fromColumn)){
			return true;
		}
		return false;
	}
	
	public boolean moveRange(int row,int col) {
		return((row == -2||row == 2) && (col == -2 || col == 2));
	}

}

