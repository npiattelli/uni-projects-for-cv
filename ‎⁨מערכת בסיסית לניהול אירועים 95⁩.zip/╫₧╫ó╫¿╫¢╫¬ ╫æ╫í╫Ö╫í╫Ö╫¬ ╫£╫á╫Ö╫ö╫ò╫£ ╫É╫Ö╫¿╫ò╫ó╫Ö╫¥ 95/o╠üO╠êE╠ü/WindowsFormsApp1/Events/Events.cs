﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30
{
    public class SupplierBid
    {
        public string supplierID { get; set; } = "";
        public string supplierName { get; set; } = "";
        public string eventID { get; set; } = "";
        public string details { get; set; } = "";
        public double price { get; set; } = 0;
        public suplierType supplierType { get; set; } 
        
        public string SupplierTypeStr { get { return supplierType.ToString(); } }
    }
    public class Event
    {
        public string eventID { get; set; } = "";
        public DateTime eventDate { get; set; }
        public string location { get; set; } = "";
        public EVENT_TYPES eventType { get; set; }
        public EVENT_STATUS eventStatus { get; set; }
        public EVENT_TIMES eventTime { get; set; }
        public double budget { get; set; }
        public string phoneNumber { get; set; } = "";
        public string customerName { get; set; } = "";
        
        public string SearchSupplierID { get; set; } = "";

        public static Boolean Create_Event(Event obj)
        {
            SqlCommand c = new SqlCommand("add_EVENTS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventDate", obj.eventDate);
            c.Parameters.AddWithValue("@location", obj.location);
            c.Parameters.AddWithValue("@eventType", obj.eventType.ToString());
            c.Parameters.AddWithValue("@eventStatus", obj.eventStatus.ToString());
            c.Parameters.AddWithValue("@eventTime", obj.eventTime.ToString());
            c.Parameters.AddWithValue("@budget", obj.budget);
            c.Parameters.AddWithValue("@phoneNumber", obj.phoneNumber);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Update_Event(Event obj)
        {
            SqlCommand c = new SqlCommand("update_EVENTS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventID", obj.eventID);
            c.Parameters.AddWithValue("@eventDate", obj.eventDate);
            c.Parameters.AddWithValue("@location", obj.location);
            c.Parameters.AddWithValue("@eventType", obj.eventType.ToString());
            c.Parameters.AddWithValue("@eventStatus", obj.eventStatus.ToString());
            c.Parameters.AddWithValue("@eventTime", obj.eventTime.ToString());
            c.Parameters.AddWithValue("@budget", obj.budget);
            c.Parameters.AddWithValue("@phoneNumber", obj.phoneNumber);
            return SQL_CON.execute_non_query(c, false);
        }
        public static List<Event> get_Events(Event obj)
        {
            SqlCommand c = new SqlCommand("Get_EVENTS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventID", obj.eventID);
            c.Parameters.AddWithValue("@phoneNumber", obj.phoneNumber);
            c.Parameters.AddWithValue("@supplierID", obj.SearchSupplierID);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Event> events = new List<Event>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Event s = new Event()
                    {
                        eventID = rdr["eventID"].ToString(),
                        budget = int.Parse( rdr["budget"].ToString()),
                        eventDate = DateTime.Parse(rdr["eventDate"].ToString()),
                        eventStatus = (EVENT_STATUS)Enum.Parse(typeof(EVENT_STATUS), rdr["eventStatus"].ToString()),
                        eventTime = (EVENT_TIMES)Enum.Parse(typeof(EVENT_TIMES), rdr["eventTime"].ToString()),
                        eventType = (EVENT_TYPES)Enum.Parse(typeof(EVENT_TYPES), rdr["eventType"].ToString()),
                        location = rdr["location"].ToString(),
                        phoneNumber = rdr["phoneNumber"].ToString(),
                        customerName= rdr["customerName"].ToString()
                    };
                    events.Add(s);
                }
            }
            return events;
        }

        public static Boolean addSupplierBid(SupplierBid obj)
        {
            SqlCommand c = new SqlCommand("add_SupplierBids");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventID", obj.eventID);
            c.Parameters.AddWithValue("@supplierID", obj.supplierID);
            c.Parameters.AddWithValue("@price", obj.price);
            c.Parameters.AddWithValue("@details", obj.details);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean GenerateOrders(string id)
        {
            SqlCommand c = new SqlCommand("GenerateOrdersFromBids");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventID", id);
            return SQL_CON.execute_non_query(c, false);
        }
        public static List<SupplierBid> get_Bids(string id)
        {
            SqlCommand c = new SqlCommand("Get_Bids");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@eventID", id);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<SupplierBid> _bids = new List<SupplierBid>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    SupplierBid s = new SupplierBid()
                    {
                        eventID = rdr["eventID"].ToString(),
                        supplierID = rdr["supplierID"].ToString(),
                        price = double.Parse(rdr["price"].ToString()),
                        details = rdr["details"].ToString(),
                        supplierName = rdr["supplierName"].ToString(),
                        supplierType= (suplierType)Enum.Parse(typeof(suplierType), rdr["SUPPLIER_TYPE"].ToString())

                };
                    _bids.Add(s);
                }
            }
            return _bids;
        }


    }
    public enum EVENT_STATUS
    {
        Finished,
        Ongoing,
        Planning
    }
    public enum EVENT_TIMES
    {
        Morning,
        Afternoon,
        Evening,
    }
    public enum EVENT_TYPES
    {
        companyEvent,
        generalEvent,
        wedding,
        barMitzva,
        batMitzva,
    }
    public enum RATINGS
    {
        one,
        two,
        three,
        four,
        five,
    }
    public enum REPORT_TITLES
    {
        Customer_Satisfaction_Survey_Results,
        Annual_Marketing_Report,
        Monthly_Financial_Review,
        Quarterly_Sales_Analysis,
    }

}
