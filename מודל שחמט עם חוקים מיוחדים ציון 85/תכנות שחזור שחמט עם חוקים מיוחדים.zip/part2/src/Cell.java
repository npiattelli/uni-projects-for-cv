public class Cell {
	private boolean isEmpty;
	private Mamal mamal;
	
	public Cell(boolean isEmpty) {
		this.isEmpty = isEmpty;
	}
	
	public Cell(Mamal mamal) {
		this.isEmpty = false;
		this.mamal=mamal;
	}
	
	public String toString(){
		if(isEmpty) {
			return "*";
		}else if(mamal!=null) {
			return mamal.toString();
		}
		return "-";
	}
	
	public boolean hasMamal() {
		return mamal !=null;
	}
	
	public boolean move(Cell [][] board , String move,boolean isPlayerMove) {
		if (!this.isEmpty()) {
			return mamal.move(board,move,isPlayerMove);
		}
		return false;
	}

	public boolean isEmpty() {
		return this.isEmpty;
	}
	
	public boolean isPlayerCell() {
		if(this.mamal == null)
			return false;
		return this.mamal.isMine(true);
	}
	public boolean isComputerCell() {
		if(this.mamal == null)
			return false;
		return this.mamal.isMine(false);
	}
	
	public Mamal getMamal() {
		return this.mamal;
	}
	
	public void clear() {
		this.isEmpty=true;
		this.mamal=null;
	}
	public boolean isThisValidSpot (){
		if (this.isEmpty && this.mamal==null) {
			return true;
		}
		return false;
	}
	public boolean isThisInvalidSpot (){
		if (!this.isEmpty && this.mamal==null) {
			return true;
		}
		return false;
	}
	
	public void setMamal(Mamal newMamal) {
		this.isEmpty=false;
		this.mamal=newMamal;
	}
	public void makeNotAvailable() {
		this.isEmpty = false;
		this.mamal=null;

	}
	
	
	public boolean isThisDraw (Cell [][] board,int fromRow,int fromCollumn) {
		if (board[fromRow][fromCollumn].hasMamal()) {
			return (this.getMamal().drawPiece(board, fromRow, fromCollumn));
		}
		return true;
	}
		

}
