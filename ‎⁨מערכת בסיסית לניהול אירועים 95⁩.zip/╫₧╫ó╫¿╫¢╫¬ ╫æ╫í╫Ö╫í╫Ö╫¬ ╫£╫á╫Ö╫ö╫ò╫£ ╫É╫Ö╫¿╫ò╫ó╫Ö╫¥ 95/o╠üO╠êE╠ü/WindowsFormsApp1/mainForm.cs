﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
            pnlCustomersArea.Visible = false;
            pnlPlannersArea.Visible = false;
            pnlPlannersArea.Top = 151;
            pnlPlannersArea.Left = (this.Width/2)-(pnlPlannersArea.Width/2);
            pnlCustomersArea.Top = 151;
            pnlCustomersArea.Left = (this.Width/2)-(pnlCustomersArea.Width/2);


        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            login_form _frm = new login_form();
            var result = _frm.ShowDialog(this);
            while (true)
            {
                if (result == DialogResult.OK)
                {
                    this.Text = this.Text + "    User:" + ApplUser.ActiveUser.UserName;
                    break;
                }
                else if (result == DialogResult.Abort)
                {
                    this.Close();
                    break;
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Suppliermain _form = new Suppliermain();
            _form.ShowDialog(this);
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            frmPayments _form = new frmPayments();
            _form.ShowDialog(this);
        }

        private void mainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            frmCustomerMain _form = new frmCustomerMain();
            _form.ShowDialog(this);
        }

        private void btnEmployees_Click(object sender, EventArgs e)
        {
            frmEmployeeMain _form = new frmEmployeeMain();
            _form.ShowDialog(this);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmEventMain _form = new frmEventMain();
            _form.ShowDialog(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void backPA_Click(object sender, EventArgs e)
        {
            pnlCustomersArea.Visible = false;
            pnlPlannersArea.Visible = false;
            pnlMain.Visible = true;
        }

        private void pbArea_Click(object sender, EventArgs e)
        {
            pnlCustomersArea.Visible = false;
            pnlPlannersArea.Visible = false;


            switch ((AppAreas) int.Parse( ((PictureBox) sender).Tag.ToString()))
            {
                case AppAreas.Customers:
                    if (ApplUser.ActiveUser.Role != "Customer") { return; }
                    pnlMain.Visible = false;
                    pnlPlannersArea.Visible = true;
                    break;
                case AppAreas.Employees:
                    if (ApplUser.ActiveUser.Role == "Customer") { return; }
                    frmShift _form = new frmShift();
                    _form.ShowDialog(this);
                    break;
                case AppAreas.Planners:
                    if (!(ApplUser.ActiveUser.Role == "CEO" || ApplUser.ActiveUser.Role == "EventManager")) { return; }
                    pnlMain.Visible = false;
                    pnlCustomersArea.Visible = true;
                    break;
            }
        }

        private enum AppAreas
        {
            Customers,
            Planners,
            Employees
        }

        private void pbCustomers_Click(object sender, EventArgs e)
        {

        }

        private void pbEmployees_Click(object sender, EventArgs e)
        {

        }

        private void pnlCustomersArea_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlPlannersArea_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void viewEvent_Click(object sender, EventArgs e)
        {
            frmSearchEvent _form = new frmSearchEvent();
            _form.CustomerPhoneNumber = ApplUser.ActiveUser.UserID;
            _form.ShowDialog(this);
        }
    }
}
