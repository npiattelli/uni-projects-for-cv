
public class LazyTurtle extends DrunkTurtle{

	public void moveForward (double distance) {
		double randNumber = Math.random();
		if (randNumber<=0.3) {
			super.moveForward(distance);
		}
		else if (randNumber<=0.5 && randNumber >0.3) {
			super.moveSober(distance);
		}
		else {
			show();
		}
	}
	
	public void turnRight (int angle) {
		double randNumber = Math.random();
		if (randNumber<=0.3) {
			super.turnRight(angle);
		}
		else if (randNumber<=0.5 && randNumber >0.3) {
			super.turnRightSober(angle);
		}
		else {
			show();
		}
	}
	
	public void turnLeft (int angle) {
		double randNumber = Math.random();
		if (randNumber<=0.3) {
			super.turnLeft(angle);
		}
		else if (randNumber<=0.5 && randNumber >0.3) {
			super.turnLeftSober(angle);
		}
		else {
			show();
		}
	}
}





