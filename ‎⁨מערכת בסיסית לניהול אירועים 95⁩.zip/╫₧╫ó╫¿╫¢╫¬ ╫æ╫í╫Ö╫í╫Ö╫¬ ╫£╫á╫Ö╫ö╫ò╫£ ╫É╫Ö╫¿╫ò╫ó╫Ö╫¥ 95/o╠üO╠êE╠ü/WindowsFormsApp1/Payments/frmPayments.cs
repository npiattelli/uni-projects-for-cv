﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmPayments : Form
    {
        public frmPayments()
        {
            InitializeComponent();
        }

        private void btnNewPayment_Click(object sender, EventArgs e)
        {
            frmNewPayment _form = new frmNewPayment();
            _form.ShowDialog(this);
        }

        private void btnCancelPayment_Click(object sender, EventArgs e)
        {
            frmCancelPayment _form = new frmCancelPayment();
            _form.ShowDialog(this);
        }

    }
}
