
import java.util.Random;
import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String [] args) {

		// TODO: 
		System.out.println("It's your turn, please enter your move:");

		start () ;
	}
	// when the player decide to start playing and represent whole player side
	public static void option1 (Cell [][] board , boolean isPlayerMove) {
		boolean gameOn = true;
		while (gameOn) {
			printBoard(board);
			System.out.println("It's your turn, please enter your move:");
			if (playerTurn ( board ,isPlayerMove)) {
				isPlayerMove  = false;
			}
			isPlayerMove  = false;
			if(Won (board , isPlayerMove )) {
				System.out.println("Congratulations, User has won :)");
				System.out.println("would you like to play again? ");
				start () ;
			}
			if (draw (board)) {
				System.out.println("Well, unfortunately it’s a Tie…");
				System.out.println("would you like to play again? ");
				start () ;
			}

			if(pcTurn(board,isPlayerMove)) {
				isPlayerMove = true;
			}
			if(Won(board , isPlayerMove )) {
				System.out.println("Sorry, Computer has won :(");
				System.out.println("would you like to play again? ");
				start () ;
			}
			if (draw (board)) {
				System.out.println("Well, unfortunately it’s a Tie…");
				System.out.println("would you like to play again? ");
				start () ;
			}
		}
	}

	public static Cell [][] createBoard() {
		Cell [][] board = new Cell [8][8];
		for (int i = 0 ; i < board.length; i++) {
			for (int j = 0 ; j < board[0].length; j++) {
				board[i][j] = new Cell (true);
			}
		}
		return board;
	}

	public static void printBoard (Cell [][] board) {
		System.out.println("The board:");
		for (int k = 0 ; k < board.length ; k++) {
			for (int j = 0 ; j < board[0].length ; j++) {
				// print board with spaces
				System.out.print(board[k][j] + " 	");
			}
			System.out.println();

		}
		System.out.println();
	}


	public static void  setNotPlayableSquares(Cell [][] board){
		for (int i = 0 ; i < board.length; i ++) {
			if ( i%2 == 0) {
				for (int j = 0 ; j < board[0].length; j = j+2) {
					board[i][j].makeNotAvailable();
				}
			}
			else {
				for (int j = 1 ; j < board[0].length; j =j+2) {
					board[i][j].makeNotAvailable();
				}
			}
		}
	}

	public static void setBoard(Cell [][] board){
		setNotPlayableSquares(board);
		setDogs(board);
		setMouse(board);
		setCats(board);
		setElephants(board);
	}

	public static void printMenu() {
		System.out.println("Welcome to Fatma Checkers \n" + "To start the game press 1:\n" + "to exit press 0:");
	}

	public static boolean validInput(String move) {
		if (move.length() != 5) {
			System.out.println("The input is not valid, please enter your move again: AA");
			return false;
		}
		String validCharts = "12345678";
		if (validCharts.indexOf(move.charAt(0)) == -1 ||
				validCharts.indexOf(move.charAt(1)) == -1 ||
				validCharts.indexOf(move.charAt(3)) == -1 ||
				validCharts.indexOf(move.charAt(4)) == -1) {
			System.out.println("The input is not valid, please enter your move again: BB");
			return false;
		}
		if (move.charAt(2) != '-') {
			System.out.println("The input is not valid, please enter your move again: CC");
			return false;
		}
		return true;
	}

	public static boolean playerSurender(String move) {
		if (move.compareTo("STOP") == 0) {
			return true;
		}
		return false;
	}

	public static void setDogs(Cell [][] board){
		//player pieces		
		board[5][6]= new Cell(new Dog(true));
		board[6][1]= new Cell(new Dog(true));
		board[7][2]= new Cell(new Dog(true));
		//computer pieces
		board[0][3]= new Cell(new Dog(false));
		board[1][0]= new Cell(new Dog(false));
		board[2][7]= new Cell(new Dog(false));

	}

	public static void setCats(Cell [][] board){
		//player pieces		
		board[5][4]= new Cell(new Cat(true));
		board[6][7]= new Cell(new Cat(true));	
		board[7][0]= new Cell(new Cat(true));
//		//computer pieces		
		board[0][1]= new Cell(new Cat(false));
		board[1][6]= new Cell(new Cat(false));
		board[2][5]= new Cell(new Cat(false));


	}

	public static void setElephants(Cell [][] board){
		//		//player pieces		
		board[5][0]= new Cell(new Elephant(true));
		board[6][3]= new Cell(new Elephant(true));
		board[7][4]= new Cell(new Elephant(true));
		//computer pieces		
		board[0][5]= new Cell(new Elephant(false));
		board[1][2]= new Cell(new Elephant(false));
		board[2][1]= new Cell(new Elephant(false));

	}

	public static void setMouse(Cell [][] board){
		//player pieces		
		board[5][2]= new Cell(new Mouse(true));
		board[6][5]= new Cell(new Mouse(true));
		board[7][6]= new Cell(new Mouse(true));
		//computer pieces
		board[0][7]= new Cell(new Mouse(false));
		board[1][4]=  new Cell(new Mouse(false));
		board[2][3]=  new Cell(new Mouse(false));


	}

	public static boolean playerTurn (Cell [][] board , boolean isPlayerMove) {
		while(isPlayerMove) {
			String move = sc.next();
			System.out.println(move);
			if (playerSurender(move) ) {
				System.out.println("Sorry, computer has won :(");
				System.out.println("would you like to play again? ");
				start();
			}
			if ( !validInput(move)) {
				System.out.println("This move is invalid, please enter a new move:");
				continue;
			}
			int fromRow=(move.charAt(3))-'0'-1;
			int fromColumn = (move.charAt(4))-'0'-1;
			if (!(board [fromRow][fromColumn].hasMamal())){
				System.out.println("This move is invalid, please enter a new move:");
				continue;
			}
			
			if(board[fromRow][fromColumn].move(board, move, isPlayerMove)) {
				printBoard(board);
				isPlayerMove = false;
			}
			else {
				//wrong case!
				System.out.println("This move is invalid, please enter a new move:");
			}
		}
		return true;
	}

	static boolean outOfBounds(int r, int c) {
		return r < 0 || r >= 8 || c < 0 || c >= 8;
	}
	
	static boolean pcCanEatOneMove(Cell [][] board, int r, int c, int r_step, int c_step) {
		
		if(outOfBounds(r+r_step, c+c_step) || outOfBounds(r+2*r_step, c+2*c_step))
			return false;
		if(!board[r+r_step][c+c_step].isPlayerCell())
			return false;
		if(!board[r+2*r_step][c+2*c_step].isEmpty())
			return false;
		
		return true;
	}
	static boolean pcEatIfCanInCell(Cell [][] board, int r, int c, int eat_step) {
		
		int[] deltafromRow = {1, 1, -1, -1};
		int[] deltafromColumn = {1, -1, -1, 1};
		int k;
		int range = 2*eat_step;
		
		if(!board[r][c].isComputerCell())
			return false;
		
		for(k=0; k<range; k++)
			if(pcCanEatOneMove(board, r, c, deltafromRow[k], deltafromColumn[k])) {
				board[r][c].getMamal().moveMamal(
						board, r+2*deltafromRow[k], c+2*deltafromColumn[k], r, c);
				board[r+deltafromRow[k]][c+deltafromColumn[k]].clear();
				return true;
			}
			
		return false;
	}
	static boolean pcEatIfCan(Cell [][] board, int eat_step) {
		int r, c;
		
		for(r=0; r<8; r++)
			for(c=0; c<8; c++)
				if(pcEatIfCanInCell(board, r, c, eat_step)) 
					return true;
		
		return false;
	}
	public static boolean pcTurn (Cell [][] board, boolean isPlayerMove) {
		
		String move = "";

		if(pcEatIfCan(board, 1)) {
			pcEatIfCan(board, 2);
		} else {
			while(true) {
				System.out.println("PC cannot eat );");
				move = NumRandom1To8 () + "-" + NumRandom1To8 ();
				int fromRow=(move.charAt(3))-'0'-1;
				int fromColumn = (move.charAt(4))-'0'-1;
				if(board[fromRow][fromColumn].hasMamal() && !(board[fromRow][fromColumn].getMamal().isPlayerMamal) && board[fromRow][fromColumn].move(board, move, isPlayerMove)) {
					System.out.println("The pc move was: " + move);
					return true;
				}
			}
		}
		
		System.out.print("error in pc turn");
		return true;
	}

	public static String NumRandom1To8 (){
		Random random = new Random();
		int first = 1 +random.nextInt(8);
		int second = 1 +random.nextInt(8);
		return (first + "" + second);
	}
	
	public static String randomEatingMoves (Cell [][] board){
		while (true) {
			Random random = new Random();
			int first = random.nextInt(8);
			int second = random.nextInt(8);
			int diff = random.nextInt(5) - 2 ;
			int diff2 = random.nextInt(5) - 2 ;
			if ((diff == 2 || diff == -2) && (diff2 == 2 || diff2 == -2 )) {
				int third = first+diff;
				int fourth = second + diff2;
				if (third >= 0  &&  third < 8 && fourth >= 0 &&  fourth <8 ) {
					int averagerow = (first +third)/2; 
					int averagecollum = (second + fourth)/2; 
					if (board[first][second].isEmpty() && (board[third][fourth].hasMamal() && !board[third][fourth].getMamal().getIsPlayerMamal() )) {
						if (board[averagerow][averagecollum].hasMamal() && board[averagerow][averagecollum].getMamal().getIsPlayerMamal()){
							return ((first+1) +"" + (second+1) +"-"+ (third+1) + "" + (fourth+1));
						}
					}
				}
			}
		}
	}	

	public static boolean Won (Cell [][] board , boolean isPlayerMove ){
		for (int i = 0 ; i< board.length ; i ++) {
			for (int k = 0 ; k< board[0].length ; k ++ ) {
				if (board [i][k].hasMamal() && !isPlayerMove) {
					if (board [i][k].getMamal().isPlayerMamal) {
						return false;
					}
				}
				if (board [i][k].hasMamal() && isPlayerMove) {
					if (!(board [i][k].getMamal().isPlayerMamal)) {
						return false;
					}
				}
			}
		}
		return true;
	}

	public static boolean isDrawOnPointPion(Cell[][] board, int i, int j) {

		int[] delta_i = {1, 1, 2, 2};
		int[] delta_j = {1, -1, 2, -2};
		int k;

		for(k=0; k<4; k++) {
			if(i+delta_i[k] > 7 || j+delta_j[k] > 7)
				continue;
			if(i+delta_i[k] < 0 || j+delta_j[k] < 0)
				continue;
			if(board[i+delta_i[k]][j+delta_j[k]].isEmpty())
				return false;
		}

		return true;
	}

	// the function checks if the are not any other valid move for a queen piece
	public static boolean isDrawOnPointQueen(Cell[][] board, int i, int j) {

		int[] delta_i = {1, 1, -1, -1, 2, 2, -2, -2};
		int[] delta_j = {1, -1, 1, -1, 2, -2, 2, -2};
		int k;

		for(k=0; k<4; k++) {
			if(i+delta_i[k] > 7 || j+delta_j[k] > 7)
				continue;
			if(i+delta_i[k] < 0 || j+delta_j[k] < 0)
				continue;
			if(board[i+delta_i[k]][j+delta_j[k]].isEmpty())
				return false;
		}

		return true;
	}

	public static boolean draw (Cell [][] board) {
		for (int i = 0 ; i< board.length ; i ++) {
			for (int k = 0 ; k< board[0].length ; k ++ ) {
				if(!(board[i][k].isThisDraw(board, i, k))) {
					return false;
				}
			}
		}
		return true;
	}

	public static void start () {

		Cell [][] board = createBoard();
		setBoard (board);
		printMenu();
		int num = sc.nextInt();
		while (num > 1 || num < 0 ) {
			System.out.println("wrong input choose oprtion 0 or option 1:");
			num = sc.nextInt();
		}
		if (num == 0 ) {
			System.out.print("ok goodbye");
		}
		else {
			option1(board , true);
		}
	}
}

