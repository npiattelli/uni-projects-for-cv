﻿namespace GROUP30
{
    partial class frmShift
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addbutton = new System.Windows.Forms.Button();
            this.remove = new System.Windows.Forms.Button();
            this.lblShift = new System.Windows.Forms.Label();
            this.available_date = new System.Windows.Forms.Label();
            this.dgvShifts = new System.Windows.Forms.DataGridView();
            this.dtpAvailableDate = new System.Windows.Forms.DateTimePicker();
            this.typeOfEvent = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.employeeID = new System.Windows.Forms.Label();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.cmbEventTime = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShifts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // addbutton
            // 
            this.addbutton.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbutton.Location = new System.Drawing.Point(154, 298);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(102, 33);
            this.addbutton.TabIndex = 0;
            this.addbutton.Text = "Add shift";
            this.addbutton.UseVisualStyleBackColor = true;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // remove
            // 
            this.remove.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remove.Location = new System.Drawing.Point(457, 298);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(132, 33);
            this.remove.TabIndex = 1;
            this.remove.Text = "Remove shift";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // lblShift
            // 
            this.lblShift.AutoSize = true;
            this.lblShift.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShift.Location = new System.Drawing.Point(284, 31);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(68, 27);
            this.lblShift.TabIndex = 2;
            this.lblShift.Text = "Shifts";
            // 
            // available_date
            // 
            this.available_date.AutoSize = true;
            this.available_date.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.available_date.Location = new System.Drawing.Point(20, 167);
            this.available_date.Name = "available_date";
            this.available_date.Size = new System.Drawing.Size(109, 21);
            this.available_date.TabIndex = 3;
            this.available_date.Text = "Available Date";
            // 
            // dgvShifts
            // 
            this.dgvShifts.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvShifts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShifts.Location = new System.Drawing.Point(405, 130);
            this.dgvShifts.Name = "dgvShifts";
            this.dgvShifts.Size = new System.Drawing.Size(240, 150);
            this.dgvShifts.TabIndex = 4;
            // 
            // dtpAvailableDate
            // 
            this.dtpAvailableDate.Location = new System.Drawing.Point(157, 168);
            this.dtpAvailableDate.Name = "dtpAvailableDate";
            this.dtpAvailableDate.Size = new System.Drawing.Size(200, 20);
            this.dtpAvailableDate.TabIndex = 5;
            // 
            // typeOfEvent
            // 
            this.typeOfEvent.AutoSize = true;
            this.typeOfEvent.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeOfEvent.Location = new System.Drawing.Point(20, 223);
            this.typeOfEvent.Name = "typeOfEvent";
            this.typeOfEvent.Size = new System.Drawing.Size(80, 21);
            this.typeOfEvent.TabIndex = 7;
            this.typeOfEvent.Text = "Shift Time";
            // 
            // back
            // 
            this.back.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(289, 332);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(102, 34);
            this.back.TabIndex = 8;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // employeeID
            // 
            this.employeeID.AutoSize = true;
            this.employeeID.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeID.Location = new System.Drawing.Point(20, 90);
            this.employeeID.Name = "employeeID";
            this.employeeID.Size = new System.Drawing.Size(97, 21);
            this.employeeID.TabIndex = 9;
            this.employeeID.Text = "Employee ID";
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(154, 91);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.ReadOnly = true;
            this.txtEmployeeID.Size = new System.Drawing.Size(127, 20);
            this.txtEmployeeID.TabIndex = 10;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(299, 91);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.ReadOnly = true;
            this.txtEmployeeName.Size = new System.Drawing.Size(277, 20);
            this.txtEmployeeName.TabIndex = 11;
            // 
            // cmbEventTime
            // 
            this.cmbEventTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEventTime.FormattingEnabled = true;
            this.cmbEventTime.Items.AddRange(new object[] {
            "Morning",
            "Afternoon",
            "Evening"});
            this.cmbEventTime.Location = new System.Drawing.Point(157, 223);
            this.cmbEventTime.Name = "cmbEventTime";
            this.cmbEventTime.Size = new System.Drawing.Size(200, 21);
            this.cmbEventTime.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GROUP30.Properties.Resources.work_schedule;
            this.pictureBox2.Location = new System.Drawing.Point(233, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(538, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // frmShift
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 378);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cmbEventTime);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.txtEmployeeID);
            this.Controls.Add(this.employeeID);
            this.Controls.Add(this.back);
            this.Controls.Add(this.typeOfEvent);
            this.Controls.Add(this.dtpAvailableDate);
            this.Controls.Add(this.dgvShifts);
            this.Controls.Add(this.available_date);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.remove);
            this.Controls.Add(this.addbutton);
            this.Name = "frmShift";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "shifts";
            this.Load += new System.EventHandler(this.shifts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvShifts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button remove;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.Label available_date;
        private System.Windows.Forms.DataGridView dgvShifts;
        private System.Windows.Forms.DateTimePicker dtpAvailableDate;
        private System.Windows.Forms.Label typeOfEvent;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label employeeID;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.ComboBox cmbEventTime;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}