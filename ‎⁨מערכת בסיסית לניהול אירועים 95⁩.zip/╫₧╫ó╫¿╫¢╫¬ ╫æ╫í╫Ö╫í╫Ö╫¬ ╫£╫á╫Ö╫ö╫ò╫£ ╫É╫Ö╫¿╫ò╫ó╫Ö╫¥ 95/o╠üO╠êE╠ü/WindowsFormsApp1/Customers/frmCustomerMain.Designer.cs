﻿namespace GROUP30
{
    partial class frmCustomerMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerLbl = new System.Windows.Forms.Label();
            this.createNewCustomer = new System.Windows.Forms.Button();
            this.SearchCustomer = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.logo = new System.Windows.Forms.PictureBox();
            this.customerPic = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPic)).BeginInit();
            this.SuspendLayout();
            // 
            // customerLbl
            // 
            this.customerLbl.AutoSize = true;
            this.customerLbl.BackColor = System.Drawing.Color.Transparent;
            this.customerLbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.customerLbl.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerLbl.Location = new System.Drawing.Point(183, 59);
            this.customerLbl.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.customerLbl.Name = "customerLbl";
            this.customerLbl.Size = new System.Drawing.Size(160, 36);
            this.customerLbl.TabIndex = 5;
            this.customerLbl.Text = "Customers";
            this.customerLbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // createNewCustomer
            // 
            this.createNewCustomer.Location = new System.Drawing.Point(265, 127);
            this.createNewCustomer.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.createNewCustomer.Name = "createNewCustomer";
            this.createNewCustomer.Size = new System.Drawing.Size(150, 100);
            this.createNewCustomer.TabIndex = 4;
            this.createNewCustomer.Text = "Create new Customer";
            this.createNewCustomer.UseVisualStyleBackColor = true;
            this.createNewCustomer.Click += new System.EventHandler(this.createNewCustomer_Click);
            // 
            // SearchCustomer
            // 
            this.SearchCustomer.Location = new System.Drawing.Point(61, 127);
            this.SearchCustomer.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.SearchCustomer.Name = "SearchCustomer";
            this.SearchCustomer.Size = new System.Drawing.Size(150, 100);
            this.SearchCustomer.TabIndex = 3;
            this.SearchCustomer.Text = "Search Customer";
            this.SearchCustomer.UseVisualStyleBackColor = true;
            this.SearchCustomer.Click += new System.EventHandler(this.SearchCustomer_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(625, 14);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(99, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.Color.Transparent;
            this.logo.Image = global::GROUP30.Properties.Resources.latizea;
            this.logo.Location = new System.Drawing.Point(341, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(129, 44);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 7;
            this.logo.TabStop = false;
            // 
            // customerPic
            // 
            this.customerPic.BackColor = System.Drawing.Color.Transparent;
            this.customerPic.Image = global::GROUP30.Properties.Resources.male_customer;
            this.customerPic.Location = new System.Drawing.Point(127, 45);
            this.customerPic.Name = "customerPic";
            this.customerPic.Size = new System.Drawing.Size(47, 50);
            this.customerPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.customerPic.TabIndex = 8;
            this.customerPic.TabStop = false;
            // 
            // frmCustomerMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::GROUP30.Properties.Resources._5631800;
            this.ClientSize = new System.Drawing.Size(482, 261);
            this.Controls.Add(this.customerPic);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.customerLbl);
            this.Controls.Add(this.createNewCustomer);
            this.Controls.Add(this.SearchCustomer);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "frmCustomerMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.frmCustomerMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label customerLbl;
        private System.Windows.Forms.Button createNewCustomer;
        private System.Windows.Forms.Button SearchCustomer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.PictureBox customerPic;
    }
}