
public class Cat extends Mamal {
	public Cat(boolean isPlayerMamal) {
		super(isPlayerMamal);
	}

	// a lot of problems with it 1- eats its on pieces 2- when he leaves a - spot he changes to a * spot 3- after one move it get stuck 
	public boolean move(Cell[][] board, String move,boolean isPlayerMove) {
		int toRow = (move.charAt(0))-'0'-1;
		int toColumn = (move.charAt(1))-'0'-1;
		int fromRow=(move.charAt(3))-'0'-1;
		int fromColumn = (move.charAt(4))-'0'-1;


		if(!checkInBounds (board,toRow,toColumn,fromRow,fromColumn)) {
			return false;
		}


		Cell toCell = board[toRow][toColumn],fromCell = board[fromRow][fromColumn];
		int avgColumn = ( toColumn + fromColumn)/2;
		int avgRow = ( toRow + fromRow)/2;
		int absRow = Math.abs((fromRow)-(toRow)) ;
		int absCol = Math.abs((fromColumn)-(toColumn));
		Cell eatenPlace = board[avgRow][avgColumn];
		if (fromCell.isEmpty() || !fromCell.getMamal().isMine(isPlayerMove) || toCell.hasMamal()) {
			return false;
		}
		if (!moveIsValid (eatenPlace,  toRow,  toColumn, fromRow, fromColumn , isPlayerMove)) {
			return false;
		}
		if (board[toRow][toColumn].isThisValidSpot() && (absCol == 0 || absRow== 0)){
			board[toRow][toColumn].setMamal(this);
			board[fromRow][fromColumn].makeNotAvailable();
			return true;
		}
		moveMamal(board,toRow,toColumn,fromRow,fromColumn);
		return true;
	}





	private boolean moveIsValid (Cell eatenPlace, int toRow, int toColumn,int fromRow,int fromColumn , boolean isPlayerMove) {
		int absRow = Math.abs((fromRow)-(toRow)) ;
		int absCol = Math.abs((fromColumn)-(toColumn));

		if (absRow <=2 && absCol <=2 ) {
			if (absRow ==0 && absCol ==0 ) {
				return false;
			}
			if (absRow <=1 && absCol <=1 ) {
				return true ;
			}

			if (!(absRow == 2 && absCol== 2) ) {
				return false;
			} 
			if (!eatenPlace.isEmpty() && !(eatenPlace.getMamal().isMine(isPlayerMove)) ) {
				eatenPlace.clear();
				return true;
			}
		}
		return false;
	}

	public String toString() {
		String id;
		if(isPlayerMamal) 
			id = "1" ;
		else
			id ="2";
		return "C"+ id;
	}
	public  boolean drawPiece (Cell[][] board, int fromRow, int fromColumn) {

		int[] deltafromRow = {0,-1,0,1,1, 1, -1, -1, 2, 2, -2, -2};
		int[] deltafromColumn = {-1,0,1,0,1, -1, 1, -1, 2, -2, 2, -2};
		int k;

		for(k=0; k<4; k++) {
			if(fromRow+deltafromRow[k] > 7 || fromColumn+deltafromColumn[k] > 7)
				continue;
			if(fromRow+deltafromRow[k] < 0 || fromColumn+deltafromColumn[k] < 0)
				continue;
			if(board[fromRow+deltafromRow[k]][fromColumn+deltafromColumn[k]].isEmpty())
				return false;
		}
		return true;
	}
	public boolean moveRange(int row,int col) {
		return((row == -2||row == 2) && (col == -2 || col == 2));
	}

}
