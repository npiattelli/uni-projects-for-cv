import Turtle.*;

public class TwoTurtles {
	
	public static void turtleRick() {
		Turtle Rick = new Turtle();
		Rick.show();
		
		Rick.tailDown();	
		Rick.moveForward(300);
		Rick.turnRight(90);
		Rick.moveForward(70);
		Rick.turnLeft(90);
		Rick.moveForward(70);
		Rick.turnLeft(90);
		Rick.moveForward(140);
		Rick.turnRight(270);
		Rick.moveForward(70);
		Rick.turnLeft(90);
		Rick.moveForward(70);
		Rick.hide();
		
	}
		
	public static void turtleMorty() {
		Turtle Morty = new Turtle();
		Morty.show();
		
		Morty.tailUp();
		Morty.moveForward(200);
		
		Morty.tailDown();
		Morty.turnRight(90);
		Morty.moveForward(100);
		
		Morty.tailUp();
		Morty.turnRight(180);
		Morty.moveForward(100);
		
		Morty.tailDown();
		Morty.moveForward(100);
		
		Morty.tailUp();
		Morty.turnRight(180);
		Morty.moveForward(100);
		Morty.turnRight(90);
		Morty.moveForward(200);
		
		Morty.tailDown();
		Morty.turnRight(320);
		Morty.moveForward(150);
		
		Morty.tailUp();
		Morty.turnLeft(180);
		Morty.moveForward(150);
		
		Morty.tailDown();
		Morty.turnLeft(100);
		Morty.moveForward(150);
		

		Morty.hide();		
	}
	
	public static void main(String[] args) {

		turtleRick();
		turtleMorty();

		
	}

}