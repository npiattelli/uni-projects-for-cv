import Turtle.*;

public class IntelligentTurtle extends Turtle {
	
	public void draw (int sides, double size) {  // draw a polygon in the given sides and size
		
		int SumOfdeg = (sides - 2)*180; //Calculate the sum of degrees in a polygon
		int SizeOfangle = SumOfdeg/sides; //Calculate each angle in a polygon
		
		tailDown();
		for(int i=0; i<sides; i++) { //draws the polygon
			
			moveForward(size);
			turnRight(180-SizeOfangle);
			}
		
		hide();
		}

}

